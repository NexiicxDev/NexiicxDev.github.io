import scss from "./MainPage.module.scss"
import * as Icons from "../../assets/icons/icons"
import { useEffect, useRef, useState } from "react"
import { IconButton } from "../../components/IconButton"

export const MainPage = () => {
  useEffect(() => {
    // Отключение контекстного меню
    const handleContextMenu = (event) => {
      event.preventDefault()
    }

    // Отключение выделения текста
    const handleMouseDown = (event) => {
      event.preventDefault()
    }

    // Отключение копирования
    const handleCopy = (event) => {
      event.preventDefault()
      alert("Копирование запрещено!")
    }

    // Отключение клавиши F12 и сочетания клавиш для инструментов разработчика
    const handleKeyDown = (event) => {
      if (
        event.key === "F12" ||
        (event.ctrlKey && event.shiftKey && event.key === "I")
      ) {
        event.preventDefault()
        event.stopPropagation()
        alert("F12 и инструменты разработчика запрещены!")
      }
    }

    // Добавление обработчиков событий
    document.addEventListener("contextmenu", handleContextMenu)
    document.addEventListener("mousedown", handleMouseDown)
    document.addEventListener("copy", handleCopy)
    window.addEventListener("keydown", handleKeyDown)

    // Очистка обработчиков событий
    return () => {
      document.removeEventListener("contextmenu", handleContextMenu)
      document.removeEventListener("mousedown", handleMouseDown)
      document.removeEventListener("copy", handleCopy)
      window.removeEventListener("keydown", handleKeyDown)
    }
  }, [])
  const tracks = [
    { title: "Гроза не грозила", src: "musik1.mp3" },
    { title: "Меллстрой", src: "musik2.mp3" },
  ]

  const [currentTrack, setCurrentTrack] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)

  const audioRef = useRef(null)
  const audioContextRef = useRef(null)
  const analyserRef = useRef(null)
  const dataArrayRef = useRef(null)
  const visualRef = useRef(null)

  useEffect(() => {
    const audioContext = new (window.AudioContext ||
      window.webkitAudioContext)()
    const analyser = audioContext.createAnalyser()
    const source = audioContext.createMediaElementSource(audioRef.current)
    source.connect(analyser)
    analyser.connect(audioContext.destination)

    analyser.fftSize = 256
    const bufferLength = analyser.frequencyBinCount
    const dataArray = new Uint8Array(bufferLength)

    audioContextRef.current = audioContext
    analyserRef.current = analyser
    dataArrayRef.current = dataArray

    return () => {
      audioContextRef.current?.close()
    }
  }, [])

  useEffect(() => {
    const animate = () => {
      if (analyserRef.current && dataArrayRef.current) {
        analyserRef.current.getByteFrequencyData(dataArrayRef.current)
        const bass =
          dataArrayRef.current.slice(0, 5).reduce((a, b) => a + b, 0) / 5

        console.log("Bass level:", bass)

        if (visualRef.current) {
          visualRef.current.style.transform = `scale(${(bass * 1.5) / 300})`
        }

        if (isPlaying) {
          requestAnimationFrame(animate)
        } else {
          if (visualRef.current) {
            visualRef.current.style.transform = "scale(1)"
          }
        }
      }
    }

    animate()
    return () => {
      if (visualRef.current) {
        visualRef.current.style.transform = "scale(1)"
      }
    }
  }, [isPlaying])

  useEffect(() => {
    const audioElement = audioRef.current

    const updateCurrentTime = () => {
      setCurrentTime(audioElement.currentTime)
    }

    const updateDuration = () => {
      if (audioElement.duration) {
        setDuration(audioElement.duration)
      }
    }

    const handleCanPlayThrough = () => {
      if (isPlaying) {
        audioElement.play().catch((error) => {
          console.error("Ошибка воспроизведения:", error)
        })
      }
    }

    audioElement.addEventListener("timeupdate", updateCurrentTime)
    audioElement.addEventListener("loadedmetadata", updateDuration)
    audioElement.addEventListener("canplaythrough", handleCanPlayThrough)
    audioElement.addEventListener("ended", () => {
      setIsPlaying(false)
      if (visualRef.current) {
        visualRef.current.style.transform = "scale(1)"
      }
    })

    return () => {
      audioElement.removeEventListener("timeupdate", updateCurrentTime)
      audioElement.removeEventListener("loadedmetadata", updateDuration)
      audioElement.removeEventListener("canplaythrough", handleCanPlayThrough)
      audioElement.removeEventListener("ended", () => {
        setIsPlaying(false)
        if (visualRef.current) {
          visualRef.current.style.transform = "scale(1)"
        }
      })
    }
  }, [currentTrack, isPlaying])

  const playPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause()
        if (audioContextRef.current) audioContextRef.current.suspend()
      } else {
        audioRef.current.play().catch((error) => {
          console.error("Ошибка воспроизведения:", error)
        })
        if (audioContextRef.current) audioContextRef.current.resume()
      }
      setIsPlaying(!isPlaying)
    }
  }

  const changeTrack = async (next) => {
    setCurrentTrack(next)
    audioRef.current.src = tracks[next].src
    audioRef.current.load()

    // Дождитесь, пока трек будет загружен
    await new Promise((resolve) => {
      audioRef.current.oncanplay = () => resolve()
    })

    // Если трек был изначально включен, сразу начинаем воспроизведение
    if (isPlaying) {
      try {
        await audioRef.current.play()
      } catch (error) {
        console.error("Ошибка воспроизведения:", error)
      }
    }
  }

  const nextTrack = async () => {
    const next = (currentTrack + 1) % tracks.length
    await changeTrack(next)
  }

  const prevTrack = async () => {
    const prev = (currentTrack - 1 + tracks.length) % tracks.length
    await changeTrack(prev)
  }

  const seek = (event) => {
    if (duration > 0) {
      const width = event.target.clientWidth
      const clickX = event.nativeEvent.offsetX
      const newTime = (clickX / width) * duration
      audioRef.current.currentTime = newTime
    }
  }

  const [transformStyle, setTransformStyle] = useState({})

  const handleMouseMove = (event) => {
    const { clientX, clientY, currentTarget } = event
    const { width, height, left, top } = currentTarget.getBoundingClientRect()

    const offsetX = clientX - (left + width / 2)
    const offsetY = clientY - (top + height / 2)

    const intensity = 20
    const rotateX = (offsetY / height) * intensity
    const rotateY = (offsetX / width) * intensity

    setTransformStyle({
      transform: `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`,
    })
  }

  return (
    <div>
      <img src="lines.svg" className="backImg1" />
      <img src="lines.svg" className="backImg2" />
      <div
        className={scss.container}
        onMouseMove={handleMouseMove}
        onMouseLeave={() => setTransformStyle({})}
      >
        <div className={scss.middle}>
          <div className={scss.infoL}>
            <h1>Привет, я</h1>
            <h1>Ефим</h1>
            <h1>{`{ Алексеев }`}</h1>
            <div className={scss.buttons}>
              <IconButton
                attr="Orders"
                icon="Settings"
                onClick={() => {
                  handleIconClick("Orders")
                }}
                className={`icon icon-primary`}
                url="Orders"
              />
              <IconButton
                attr="Orders"
                icon="Settings"
                onClick={() => {
                  handleIconClick("Orders")
                }}
                className={`icon icon-primary`}
                url="Orders"
              />
              <IconButton
                attr="Orders"
                icon="Settings"
                onClick={() => {
                  handleIconClick("Orders")
                }}
                className={`icon icon-primary`}
                url="Orders"
              />
            </div>
            <img className={scss.mouse} src="Vector.png" />
          </div>
          <div ref={visualRef} className={scss.infoM}>
            <img
              onMouseMove={handleMouseMove}
              onMouseLeave={() => setTransformStyle({})}
              src="Group 1.png"
              style={{
                width: "100%",
                height: "100%",
                transition: "transform 0.1s ease-out",
                ...transformStyle,
              }}
            />
            <div></div>
          </div>

          <div className={scss.infoR}>
            <div className={scss.musik}>
              <h2 className={scss.name}>{tracks[currentTrack].title} </h2>
              <audio
                ref={audioRef}
                src={tracks[currentTrack].src}
                onTimeUpdate={() =>
                  setCurrentTime(audioRef.current.currentTime)
                }
              ></audio>
              <div className={scss.time}>
                {`${Math.floor(currentTime / 60)} м ${Math.floor(
                  currentTime % 60
                )} с`}
                <div
                  style={{
                    height: "10px",
                    width: "100%",
                    background: "#ccc",
                    position: "relative",
                  }}
                  onClick={seek}
                >
                  <div
                    style={{
                      width: `${
                        duration > 0 ? (currentTime / duration) * 100 : 0
                      }%`,
                      height: "100%",
                      background: "#3b82f6",
                      position: "absolute",
                      top: 0,
                      left: 0,
                    }}
                  ></div>
                </div>
                {`${Math.floor(duration / 60)} м ${Math.floor(
                  duration % 60
                )} с`}
              </div>

              <div className={scss.buttons}>
                <button onClick={prevTrack}>
                  <Icons.Post />
                </button>
                <button onClick={playPause}>
                  {isPlaying ? <Icons.Pause /> : <Icons.Go />}
                </button>
                <button onClick={nextTrack}>
                  <Icons.Next />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
