export { ErrorsPage } from "./ErrorsPage"
export { MainPage } from "./MainPage"
