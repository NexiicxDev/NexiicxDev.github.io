import scss from "./ErrorsPage.module.scss"
import * as Icons from "../../assets/icons/icons"
export const ErrorsPage = () => {
  return <div></div>
}
